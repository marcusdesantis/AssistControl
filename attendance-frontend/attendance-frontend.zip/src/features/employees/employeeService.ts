import { api } from '@/services/api'
import type { Employee, CreateEmployeeRequest, UpdateEmployeeRequest } from '@/types/employee'
import type { PagedResult } from '@/types/pagination'

interface ApiResponse<T> {
  success: boolean
  message?: string
  data?: T
  errorCode?: string
}

export interface EmployeeFilters {
  page?:       number
  pageSize?:   number
  search?:     string
  department?: string
  status?:     string
}

export interface CreateEmployeeResult {
  employee:           Employee
  generatedPin:       string | null
  generatedPassword:  string | null
}

export const employeeService = {
  getPaged: async (filters: EmployeeFilters = {}): Promise<PagedResult<Employee>> => {
    const params = {
      page:       filters.page       ?? 1,
      pageSize:   filters.pageSize   ?? 20,
      ...(filters.search     && { search:     filters.search }),
      ...(filters.department && { department: filters.department }),
      ...(filters.status     && { status:     filters.status }),
    }
    const res = await api.get<ApiResponse<PagedResult<Employee>>>('/employees', { params })
    return res.data.data!
  },

  // Mantener getAll para casos que necesiten la lista completa (ej: modal de mensajes)
  getAll: async (): Promise<Employee[]> => {
    const res = await api.get<ApiResponse<PagedResult<Employee>>>('/employees', {
      params: { page: 1, pageSize: 500 }
    })
    return res.data.data?.items ?? []
  },

  getById: async (id: string): Promise<Employee> => {
    const res = await api.get<ApiResponse<Employee>>(`/employees/${id}`)
    return res.data.data!
  },

  getNextCode: async (): Promise<{ nextCode: string; prefix: string }> => {
    const res = await api.get<ApiResponse<{ nextCode: string; prefix: string }>>('/employees/next-code')
    return res.data.data!
  },

  create: async (data: CreateEmployeeRequest): Promise<CreateEmployeeResult> => {
    const res = await api.post<ApiResponse<CreateEmployeeResult>>('/employees', data)
    return res.data.data!
  },

  update: async (id: string, data: UpdateEmployeeRequest): Promise<Employee> => {
    const res = await api.put<ApiResponse<Employee>>(`/employees/${id}`, data)
    return res.data.data!
  },

  delete: async (id: string): Promise<void> => {
    await api.delete(`/employees/${id}`)
  },

  sendCredentials: async (id: string): Promise<void> => {
    const res = await api.post<ApiResponse<null>>(`/employees/${id}/send-credentials`)
    if (!res.data.success)
      throw new Error(res.data.message ?? 'Error al enviar credenciales')
  },
}
