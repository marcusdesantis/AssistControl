import { api } from '@/services/api'
import type { EmployeeMessage } from '@/types/message'
import type { PagedResult } from '@/types/pagination'

interface ApiResponse<T> { success: boolean; message?: string; data?: T }

export const messageService = {
  getByEmployee: async (employeeId: string, page = 1, pageSize = 15): Promise<PagedResult<EmployeeMessage>> => {
    const res = await api.get<ApiResponse<PagedResult<EmployeeMessage>>>(
      `/messages/employee/${employeeId}`, { params: { page, pageSize } }
    )
    return res.data.data!
  },

  create: async (payload: {
    employeeIds?: string[]
    forAll: boolean
    subject: string
    body: string
    allowDelete: boolean
  }): Promise<number> => {
    const res = await api.post<ApiResponse<number>>('/messages', payload)
    return res.data.data ?? 0
  },

  delete: async (id: string): Promise<void> => {
    await api.delete(`/messages/${id}`)
  },

  markReadChecker: async (messageId: string, checkerKey: string): Promise<void> => {
    await api.post(`/checker/messages/${messageId}/read?checkerKey=${encodeURIComponent(checkerKey)}`)
  },
}
