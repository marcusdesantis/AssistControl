import { createBrowserRouter, Navigate } from 'react-router-dom'
import LoginPage from '@/features/auth/LoginPage'
import ChangePasswordPage from '@/features/auth/ChangePasswordPage'
import ProtectedRoute from '@/components/ProtectedRoute'
import Layout from '@/components/Layout'
import DashboardPage from '@/features/dashboard/DashboardPage'
import EmployeesPage from '@/features/employees/EmployeesPage'
import AttendancePage from '@/features/attendance/AttendancePage'
import SchedulesPage  from '@/features/schedules/SchedulesPage'
import MessagesPage   from '@/features/messages/MessagesPage'
import CheckerPage from '@/features/checker/CheckerPage'
import ReportsPage     from '@/features/reports/ReportsPage'
import CompanyPage     from '@/features/company/CompanyPage'
import OrganizationPage from '@/features/organization/OrganizationPage'
import SettingsPage    from '@/features/settings/SettingsPage'
import RegisterPage    from '@/features/settings/RegisterPage'

export const router = createBrowserRouter([
  { path: '/login',            element: <LoginPage /> },
  { path: '/change-password',  element: <ChangePasswordPage /> },
  { path: '/checker',          element: <CheckerPage /> },   // público — kiosk
  { path: '/register/:token',  element: <RegisterPage /> },  // público — auto-registro
  {
    element: <ProtectedRoute />,
    children: [
      {
        element: <Layout />,
        children: [
          { path: '/',          element: <Navigate to="/dashboard" replace /> },
          { path: '/dashboard', element: <DashboardPage /> },
          { path: '/employees',    element: <EmployeesPage /> },
          { path: '/organization', element: <OrganizationPage /> },
          { path: '/schedules',    element: <SchedulesPage /> },
          { path: '/attendance',element: <AttendancePage /> },
          { path: '/messages',  element: <MessagesPage /> },
          { path: '/reports',   element: <ReportsPage /> },
          { path: '/company',   element: <CompanyPage /> },
          { path: '/settings',  element: <SettingsPage /> },
        ],
      },
    ],
  },
  { path: '*', element: <Navigate to="/dashboard" replace /> },
])
