import axios from 'axios'
import { useAuthStore } from '@/store/authStore'

// En desarrollo: BASE_URL vacío → usa el proxy de Vite (/api → http://localhost:5000)
// En producción: define VITE_API_URL en el .env (ej: https://api.tudominio.com)
const BASE_URL = 'http://167.86.87.213:5000'

export const api = axios.create({
  baseURL: `${BASE_URL}/api/v1`,
  headers: { 'Content-Type': 'application/json' },
  timeout: 15000,
})

// ─── Request: adjuntar JWT ────────────────────────────────────────────────────
api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().accessToken
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// ─── Response: renovar token si expira (401) ─────────────────────────────────
let isRefreshing = false
let failedQueue: Array<{ resolve: (v: string) => void; reject: (e: unknown) => void }> = []

const processQueue = (error: unknown, token: string | null) => {
  failedQueue.forEach((p) => (error ? p.reject(error) : p.resolve(token!)))
  failedQueue = []
}

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const originalRequest = error.config

    // Las rutas del checador son públicas (sin JWT) — no aplicar refresh ni redirigir al login
    if (originalRequest?.url?.includes('/checker/')) {
      return Promise.reject(error)
    }

    if (error.response?.status !== 401 || originalRequest._retry) {
      return Promise.reject(error)
    }

    if (isRefreshing) {
      return new Promise((resolve, reject) => {
        failedQueue.push({ resolve, reject })
      }).then((token) => {
        originalRequest.headers.Authorization = `Bearer ${token}`
        return api(originalRequest)
      })
    }

    originalRequest._retry = true
    isRefreshing = true

    const { refreshToken, updateAccessToken, clearAuth } = useAuthStore.getState()

    try {
      // Usar la misma instancia api para pasar por el proxy de Vite también
      const res = await axios.post(`${BASE_URL}/api/v1/auth/refresh`, { token: refreshToken })
      const newToken: string = res.data.data.accessToken
      updateAccessToken(newToken)
      processQueue(null, newToken)
      originalRequest.headers.Authorization = `Bearer ${newToken}`
      return api(originalRequest)
    } catch (err) {
      processQueue(err, null)
      clearAuth()
      window.location.href = '/login'
      return Promise.reject(err)
    } finally {
      isRefreshing = false
    }
  }
)
