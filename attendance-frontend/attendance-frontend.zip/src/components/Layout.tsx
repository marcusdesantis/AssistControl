import { useState } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import {
  Clock, LayoutDashboard, Users, CalendarCheck,
  BarChart3, Settings, LogOut, Menu, X, ChevronRight, ScanLine, CalendarDays, MessageSquare, Building2, Network
} from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { authService } from '@/features/auth/authService'
import clsx from 'clsx'

const navItems = [
  { to: '/dashboard',    icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/company',      icon: Building2,        label: 'Empresa' },
  { to: '/organization', icon: Network,          label: 'Catálogos' },
  { to: '/employees',    icon: Users,            label: 'Empleados' },
  { to: '/schedules',    icon: CalendarDays,     label: 'Horarios' },
  { to: '/attendance',   icon: CalendarCheck,    label: 'Asistencia' },
  { to: '/messages',     icon: MessageSquare,    label: 'Mensajes' },
  { to: '/reports',      icon: BarChart3,        label: 'Reportes' },
  { to: '/settings',     icon: Settings,         label: 'Configuración' },
]

export default function Layout() {
  const navigate = useNavigate()
  const { user, clearAuth } = useAuthStore()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const handleLogout = async () => {
    try { await authService.logout() } catch { /* ignorar */ }
    clearAuth()
    navigate('/login', { replace: true })
  }

  const roleLabel: Record<string, string> = {
    Admin: 'Administrador',
    Supervisor: 'Supervisor',
    Employee: 'Empleado',
  }

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">

      {/* Overlay móvil */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={clsx(
        'fixed top-0 left-0 h-full w-64 bg-primary-900 text-white z-30 flex flex-col transition-transform duration-300',
        'lg:relative lg:translate-x-0',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      )}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-5 border-b border-primary-700">
          <div className="w-9 h-9 bg-primary-600 rounded-lg flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5 text-white" />
          </div>
          <div className="min-w-0">
            <p className="font-bold text-sm leading-tight truncate">Control de Asistencia</p>
            <p className="text-primary-300 text-xs truncate">v1.0</p>
          </div>
          <button className="lg:hidden ml-auto" onClick={() => setSidebarOpen(false)}>
            <X className="w-5 h-5 text-primary-300" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          {navItems.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) => clsx(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors group',
                isActive
                  ? 'bg-primary-700 text-white'
                  : 'text-primary-200 hover:bg-primary-800 hover:text-white'
              )}
            >
              <Icon className="w-5 h-5 shrink-0" />
              <span className="flex-1">{label}</span>
              <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-50 transition-opacity" />
            </NavLink>
          ))}
        </nav>

        {/* User info + logout */}
        <div className="border-t border-primary-700 p-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-9 h-9 bg-primary-600 rounded-full flex items-center justify-center text-sm font-bold shrink-0">
              {user?.username?.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium truncate">{user?.username}</p>
              <p className="text-primary-300 text-xs truncate">{roleLabel[user?.role ?? ''] ?? user?.role}</p>
            </div>
          </div>
          <a
            href="/checker"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center gap-2 px-3 py-2 text-primary-200 hover:text-white hover:bg-primary-800 rounded-lg text-sm transition-colors mb-1"
          >
            <ScanLine className="w-4 h-4" />
            Reloj Checador
          </a>
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-3 py-2 text-primary-200 hover:text-white hover:bg-primary-800 rounded-lg text-sm transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Cerrar sesión
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Topbar */}
        <header className="bg-white border-b border-gray-200 h-14 flex items-center px-4 shrink-0">
          <button
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100 mr-2"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5 text-gray-600" />
          </button>
          <div className="flex-1" />
          <span className="text-sm text-gray-500">
            {new Date().toLocaleDateString('es-EC', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </span>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
