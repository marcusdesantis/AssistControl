export interface UserInfo {
  id: string
  username: string
  email: string
  role: 'Admin' | 'Supervisor' | 'Employee'
  tenantId: string
  mustChangePassword: boolean
}

export interface LoginRequest {
  username: string
  password: string
}

export interface LoginResponse {
  accessToken: string
  refreshToken: string
  expiresAt: string
  user: UserInfo
}

export interface ApiResponse<T = unknown> {
  success: boolean
  message: string | null
  data: T | null
  errorCode: string | null
  errors: string[]
}
